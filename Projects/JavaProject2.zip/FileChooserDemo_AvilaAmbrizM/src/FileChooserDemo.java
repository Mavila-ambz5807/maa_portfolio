/**
 *
 * @author Mariana Avila Ambriz
 */
import javafx.application.Application;
import javafx.stage.Stage;
import javafx.stage.FileChooser;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.VBox;
import java.io.File;

public class FileChooserDemo extends Application
{
    private Label outputLabel;
    
    public static void main(String[] args)
    {
        launch(args);
    }
    
    @Override
    public void start(Stage primaryStage)
    {
        // Create the FileChooser object
        FileChooser fileChooser = new FileChooser();
        fileChooser.setTitle("Select a File");

        // Optional: Add file type filters
        fileChooser.getExtensionFilters().addAll(
            new FileChooser.ExtensionFilter("Java Files (*.java)", "*.java"),
            new FileChooser.ExtensionFilter("Text Files (*.txt)", "*.txt"),
            new FileChooser.ExtensionFilter("All Files (*.*)", "*.*")
        );

        // Create buttons
        Button openButton = new Button("Open File");
        Button saveButton = new Button("Save File");

        // Label to display the file path
        outputLabel = new Label("No file selected.");

        // Open File button action
        openButton.setOnAction(e -> {
            File selectedFile = fileChooser.showOpenDialog(primaryStage);
            if (selectedFile != null) {
                outputLabel.setText("You selected: " + selectedFile.getPath());
            } else {
                outputLabel.setText("Open command cancelled.");
            }
        });

        // Save File button action
        saveButton.setOnAction(e -> {
            File selectedFile = fileChooser.showSaveDialog(primaryStage);
            if (selectedFile != null) {
                outputLabel.setText("File will be saved as: " + selectedFile.getPath());
            } else {
                outputLabel.setText("Save command cancelled.");
            }
        });

        // Layout
        VBox vbox = new VBox(10, openButton, saveButton, outputLabel);
        vbox.setStyle("-fx-padding: 20; -fx-alignment: center; -fx-font-size: 14;");

        // Scene and stage setup
        Scene scene = new Scene(vbox, 400, 200);
        primaryStage.setTitle("FileChooser Demo");
        primaryStage.setScene(scene);
        primaryStage.show();
    }  

}

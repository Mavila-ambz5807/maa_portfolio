/**
 * A program that displays a coin flipping
 * @author Mariana Avila Ambriz
 */
import javafx.application.Application;
import javafx.stage.Stage;
import javafx.scene.Scene;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.VBox;
import javafx.geometry.Pos;
import javafx.geometry.Insets;
import java.util.Random;

public class CoinToss extends Application
{
    public static void main(String[] args)
    {
        //Launch the application
       launch(args);
    }
    
    @Override
    public void start(Stage primaryStage) 
    {
        // Load images
        Image headsImage = new Image("Heads1.png");
        Image tailsImage = new Image("Tails1.png");

        // Create ImageView to show the coin 
        ImageView coinImage = new ImageView(headsImage);
        coinImage.setFitWidth(200);
        coinImage.setFitHeight(200);

        //  VBox layout container
        VBox mainVBox = new VBox(coinImage);
        mainVBox.setAlignment(Pos.CENTER);
        mainVBox.setPadding(new Insets(10));

        // Scene
        Scene scene = new Scene(mainVBox, 300, 300);

        // KEY PRESS EVENT HANDLER  
        scene.setOnKeyPressed(e -> {
            Random rand = new Random();
            int value = rand.nextInt(2);

            if (value == 0)
                coinImage.setImage(headsImage);
            else
                coinImage.setImage(tailsImage);
        });

        // Show the window
        primaryStage.setScene(scene);
        primaryStage.setTitle("Coin Toss Simulator");
        primaryStage.show();
    }
}

#Mariana Avila Ambriz

import json
import os

# ===============================
# Employee Class
# ===============================
class Employee:
    def __init__(self, emp_id, name, department, role, salary):
        self.emp_id = emp_id
        self.name = name
        self.department = department
        self.role = role
        self.salary = salary

    def to_dict(self):
        return {
            "ID": self.emp_id,
            "Name": self.name,
            "Department": self.department,
            "Role": self.role,
            "Salary": self.salary
        }


# ===============================
# Manager Class
# ===============================
class EmployeeManager:
    def __init__(self, file_name="employees.json"):
        self.file_name = file_name
        self.employees = self.load_data()

    def load_data(self):
        if os.path.exists(self.file_name):
            with open(self.file_name, "r") as file:
                return json.load(file)
        return {}

    def save_data(self):
        with open(self.file_name, "w") as file:
            json.dump(self.employees, file, indent=4)

    def add_employee(self):
        emp_id = input("Enter Employee ID: ")
        if emp_id in self.employees:
            print("⚠ Employee already exists!")
            return

        name = input("Enter Name: ")
        dept = input("Enter Department: ")
        role = input("Enter Role: ")
        salary = float(input("Enter Salary: "))

        emp = Employee(emp_id, name, dept, role, salary)
        self.employees[emp_id] = emp.to_dict()
        self.save_data()

        print("✅ Employee Added Successfully!")

    def view_all(self):
        if not self.employees:
            print("⚠ No employees found.")
            return

        print("\n--- Employee List ---")
        for emp in self.employees.values():
            print(emp)

    def search_employee(self):
        emp_id = input("Enter Employee ID: ")
        if emp_id in self.employees:
            print(self.employees[emp_id])
        else:
            print("❌ Employee not found")

    def update_employee(self):
        emp_id = input("Enter Employee ID: ")
        if emp_id not in self.employees:
            print("❌ Employee not found")
            return

        print("Leave blank to keep old value")

        name = input("New Name: ")
        dept = input("New Department: ")
        role = input("New Role: ")
        salary = input("New Salary: ")

        emp = self.employees[emp_id]

        if name: emp["Name"] = name
        if dept: emp["Department"] = dept
        if role: emp["Role"] = role
        if salary: emp["Salary"] = float(salary)

        self.save_data()
        print("✅ Employee Updated!")

    def delete_employee(self):
        emp_id = input("Enter Employee ID: ")
        if emp_id in self.employees:
            del self.employees[emp_id]
            self.save_data()
            print("🗑 Employee Deleted")
        else:
            print("❌ Employee not found")


# ===============================
# Menu System
# ===============================
def main():
    manager = EmployeeManager()

    while True:
        print("\n===== Employee Management System =====")
        print("1. Add Employee")
        print("2. View All Employees")
        print("3. Search Employee")
        print("4. Update Employee")
        print("5. Delete Employee")
        print("6. Exit")

        choice = input("Choose an option: ")

        if choice == "1":
            manager.add_employee()
        elif choice == "2":
            manager.view_all()
        elif choice == "3":
            manager.search_employee()
        elif choice == "4":
            manager.update_employee()
        elif choice == "5":
            manager.delete_employee()
        elif choice == "6":
            print("👋 Exiting system...")
            break
        else:
            print("❌ Invalid option")


if __name__ == "__main__":
    main()
# Simple Math Calculator
# Mariana Avila Ambriz

num1 = float(input("Enter the first number: "))
operator = input("Enter an operator (+, -, *, /): ")
num2 = float(input("Enter the second number: "))

if operator == "+":
    result = num1 + num2
    print("Answer:", result)

elif operator == "-":
    result = num1 - num2
    print("Answer:", result)

elif operator == "*":
    result = num1 * num2
    print("Answer:", result)

elif operator == "/":
    if num2 != 0:
        result = num1 / num2
        print("Answer:", result)
    else:
        print("Error: Cannot divide by zero.")

else:
    print("Invalid operator.")